<?php
class Person{
	public $name;
	public $age;
	
	public function __construct($nam, $boyos){
			$this->name = $nam;
			$this->age = $boyos;
	}
	public function personDetails(){
		echo "Person Name is {$this->name} 
		& his age is {$this->age}";
	}
}

$obj = new Person("Ronnie", 22);
$obj->personDetails();
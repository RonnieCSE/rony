<?php
class Student{
	public function __call($absent, $serial){
		echo "Here ".$absent." roll numbers are ".
		implode(' ,', $serial);
	}
}
$obj = new Student();
$obj->absence('3','5','4','8','9','7','6');
?>
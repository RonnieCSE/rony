<?php
class Php{
	public function framework(){
		echo "Laravel is a framework <br>";
		return $this;
	}
	public function cms(){
		echo "Wordpress ia a CMS";
		return $this;
	}
}
$obj = new Php();
$obj->framework()->cms();
?>
<?php
interface School{
	public function mySchool();
}
interface Collage{
	public function myCollage();
}
interface Versity{
	public function myVersity();
}

class Teacher implements School, Collage, Versity{
	
	public function __construct(){
		$this->mySchool();
		$this->myCollage();
		$this->myVersity();
	}
	
	public function mySchool(){
		echo "I am a School Teacher <br>";
	}
	public function myCollage(){
		echo "I am a Collage Teacher <br>";
	}
	public function myVersity(){
		echo "I am a Versity Teacher <br>";
	}
}
$obj = new Teacher();
?>
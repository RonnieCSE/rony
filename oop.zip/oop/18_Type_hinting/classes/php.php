<?php 
class Php{
	public function framework(){
		echo "Cakephp is a framework";
	}
	public function cms(){
		echo "Wordpress is a cms";
	}
}
?>

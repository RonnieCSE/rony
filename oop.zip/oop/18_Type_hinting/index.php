<?php
spl_autoload_register(function($className){
	include "classes/". $className. ".php";
});
$php = new Php();
new Java($php);

?>
<?php
//trait merge
trait Java{
	public function javaCoder(){
		return "I love Java <br>";
	}
}
trait Php{
	public function phpCoder(){
		return "I love Php";
	}
}
class One{
	use Java,Php;
}
$j = new One();
echo $j->javaCoder();
echo $j->phpCoder();

?>
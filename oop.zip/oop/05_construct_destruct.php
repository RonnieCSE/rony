<?php
class UserData{
	public $user;
	public $userId;
	
	public function __construct($nam, $id){
		$this->user = $nam;
		$this->userId = $id;
	
	echo "Username is {$this->user} &
		userId is {$this->userId}";
	}
	
	public function __destruct(){
		unset($this->user);
		unset($this->userId);
	}
	
}
$obj = new UserData("Ronnie", 23);
?>
<?php
trait Java{
	public function javaCoder(){
		return "I love Java <br>";
	}
}
trait Php{
	public function phpCoder(){
		return "I love Php";
	}
}
class One{
	use Java;
}
class Two{
	use Php;
}
$j = new One();
echo $j->javaCoder();

$p = new Two();
echo $p->phpCoder();

?>
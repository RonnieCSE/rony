<?php
class Student{
	public function __get($pm){
		echo " $pm is on!!";
	}
}
$obj = new Student();
$obj->Ronnie;
?>
<?php
class Student{
	public function __set($name, $age){
		echo "We set $name = $age";
	}
}
$obj = new Student();
$obj->name = 22;
?>
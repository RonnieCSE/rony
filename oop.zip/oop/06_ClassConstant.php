<?php
class UserData{
	const NAME = "MD. Ariful Islam Ronnie";
	public function display(){
		echo "FullName is ".UserData::NAME;
	}
}
$obj = new UserData();
$obj->display();
?>
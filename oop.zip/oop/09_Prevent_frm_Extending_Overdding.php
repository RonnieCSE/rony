<?php
// Prevent from Extending & overidding
class final UserData{
	public $user;
	public $userId;
	
	public function __construct($nam, $id){
		$this->user = $nam;
		$this->userId = $id;
	}
	public function display(){
		echo "Username  is {$this->user} & userId is {$this->userId}";
	}
}

$obj = new UserData("Ronnie", 22);
$obj->display();
?>




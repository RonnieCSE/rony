<?php
$arr = array("Html", "css", "js", "java");
$code = new ArrayObject($arr);
$iterator = $code->getIterator();

while($iterator->valid()){
	echo $iterator->current()."<br>";
	$iterator->next();
}

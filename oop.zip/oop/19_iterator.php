<?php
class Inform{
	public $name = "Ronnie";
	public $age = 21;
	public $skill = "coding";
	
	private $email = "r@gmail.com";
	protected $pass = "123";
	
	function Inner(){
		foreach($this as $key => $val){
			echo "<pre>";
			echo "$key => $val";
			echo "</pre>";
		}
	}
}
$obj = new Inform();
$obj->Inner();
?>
<?php
interface School{
	public function mySchool();
}

class Teacher implements School{
	public function __construct(){
		$this->mySchool();
	}
	public function mySchool(){
		echo "This is Ronnie";
	}
}
$obj = new Teacher();
?>
<?php
class Php{
	private $category;
	private $framework;
	
	function setCat($a){
		$this->category = $a;
	}
	function getCat(){
		return  $this->category ."<br>";
	}
	
	function setFramework($b){
		$this->framework = $b;
	}
	function getFramework(){
		return $this->framework ."<br>";
	}
	
	
	public function __clone(){
		$lang = new Php;
		$lang->setFramework($this->framework);
		return $lang;
	}
 	
}
?>
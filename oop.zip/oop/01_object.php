<?php
// class, Object, Property,

class Person{
	public $name;
	public $age;
	
	public function personName(){
		echo "Person Name is : ".$this->name;
	}
	
	public function personAge($years){
		echo "Person Age is ".$this->age = $years;
	}
}
$obj = new Person();
$obj->name = "Ronnie";
$obj->personName();

echo "<br>";
$obj->personAge("23");
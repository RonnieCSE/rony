<?php
class Admin extends UserData{
	Public $level = "DBA";
	public function displays(){
		echo "Username is {$this->user}&
		UserId is {$this->userId} & level is {$this->level}";
	}
}



?>
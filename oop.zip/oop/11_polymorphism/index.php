<?php
	require "polymorphism.php";
	
class UserDa ta{
	public $user;
	public $userId;
	
	public function __construct($nam, $id){
		$this->user = $nam;
		$this->userId = $id;
	}
	
	public function display(){
		echo "Username is {$this->user} &
			UserId is {$this->userId}";
	}
}

$obj = new admin("Ronnie", 4);
$obj->displays();
//if ($obj instanceof UserData)
?>
<?php
include "classes/Java.php";
include "classes/Ruby.php";
include "classes/Php.php";
include "classes/Python.php";

new Ronnie\Java();
echo HTML;
echo Ronnie\CSS;
Ronnie\Coding();

new Ronnie\Php();
new Ronnie\hasan\Ruby();

use Kamal\joy\Python as ru;
new ru();
?>
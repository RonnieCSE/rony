<?php
namespace Kamal\joy;
class Python{
	function __construct(){
		echo "I am Learning Python <br>";
	}
}
?>
<?php
namespace Ronnie;
class Java{
	function __construct(){
		echo "I am Learning Java <br>";
	}
}
define("HTML", "I know Html. <br>");

const CSS = "I love CSS <br>";

function Coding(){
	echo "I am a Coder";
}
?>
<?php
namespace Ronnie;
class Php{
	function __construct(){
		echo "I am learning Php <br>";
	}
}


?>
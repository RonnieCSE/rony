<?php
namespace Ronnie\hasan;
class Ruby{
	function __construct(){
		echo "I am learning Ruby <br>";
	}
}


?>
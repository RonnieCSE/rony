<?php
// abstract class

abstract class Students{
	public $name;
	public $age;
	
	public function details(){
		echo $this->name ." is ".$this->age. " years old";
	}
}

class Boy extends Students{
	public function describe(){
		return parent::details();
	}
}
$obj = new Boy();
$obj->name = "Ronnie";
$obj->age = 22;
$obj->describe();
?>
<?php
class Php{
	public $a;
	
	public function getValue(array $x){
		foreach($x as $value){
			echo $value[0];
			echo " : ";
			echo $value[1]*$value[2]."<br>";
		}
	}
}

$num = array(
	array('Number One',10,10),
	array('Number Two', 20, 20)
);
	
$obj = new Php();
$obj->getValue($num);
?>
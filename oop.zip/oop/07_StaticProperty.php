<?php
//static property access
class UserData{
	public static $name = "Ronnie";
	
	public function display(){
		echo "My name is ".self::$name;
	}
}
$obj = new UserData();
$obj->display();

?>
<?php
require "php.php";

$obj = new Php();
$obj->setCat("OOP");
$obj->setFramework("Spring");

$php = clone $obj;
$php->setCat("Laravel");
$php->setFramework("CodeIgnitor");

echo $obj->getCat();
echo $obj->getFramework();

echo $php->getCat();
echo $php->getFramework();
?>

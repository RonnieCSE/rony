<?php
//static Method access
class UserData{
	public static $name = "Ronnie";
	
	public static function display(){
		echo "Name is ".self::$name;
	}
}
$obj = new UserData();
UserData::display();
?>
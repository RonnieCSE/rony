<?php
$arr = array("Html", "css", "js", "java");
$obj = new ArrayIterator($arr);

echo $obj->current()."<br>";
$obj->next();
echo $obj->current();
?>
<hr />
<?php
$arr = array("css", "Java", "ajax", "jSon");
$obj = new ArrayIterator($arr);

foreach($obj as $value){
	echo $value."<br>";
}
?>
<hr />
<?php
$arr = array("Html", "css", "js", "java");
$obj = new ArrayIterator($arr);

$limit = new limitIterator($obj, 2, 3);

foreach($limit as $value){
	echo $value. "<br>";
}
?>
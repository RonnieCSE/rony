<?php
// Inheritance 
class UserData{
	public $user;
	public $userId;
	
	public function __construct($nam, $id){
		$this->user = $nam;
		$this->userId = $id;
	}
}

class Admin extends UserData{
	public $level;
	public function display(){
		echo "Username name is {$this->user} & userId is {$this->userId} & User Level is {$this->level}";
	}
}

$obj = new Admin("Ronnie", 22);
$obj->level = "DBA";
$obj->display();

?>




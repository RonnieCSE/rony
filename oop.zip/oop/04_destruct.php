<?php
class Person{
	public $name;
	public $age;
	public $id;
	
	public function __construct($nam, $boyos){
		echo $this->name = $nam;
		echo $this->age = $boyos;
	}
	public function setId($id){
		$this->id = $id;
	}
	public function __destruct(){
		if(!empty($this->id)){
			echo "Saving Person";
		}
	}
}
$obj = new Person("Ronnie", 23);
$obj->setId(12);
unset($obj);

?>
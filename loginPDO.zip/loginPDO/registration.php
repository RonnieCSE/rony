<?php
require 'db.php';



$error  = array();
$message = '';
$message2 = '';
//$message = '';
//if($_SERVER['REQUEST_METHOD'] == 'POST'){
if(isset($_POST['submit'])){
	if(empty($_POST['username'])){
		$error[] = "You must enter your username";
	}
	if(empty($_POST['email'])){
		$error[] = "You must enter your Email";
	}
	if(empty($_POST['password'])){
		$error[] = "You must enter your Password!!";
	}elseif(empty($_POST['confirm_password'])){
		$error[] = "You must enter a confirm password!!";
	}elseif($_POST['password'] !== $_POST['confirm_password']){
		$error[] = "your both password should be match!!";
	}
	
	if(!empty($error)){
		foreach ($error as $single_error){
			$message .= $single_error."<br>";
		}
	}else{
		//Send Data to database
		$new = $connection->prepare("INSERT INTO users(username, email, password) VALUES (:username, :email, :password)");
		$new->bindParam(':username', $_POST['username']);
		$new->bindParam(':email', $_POST['email']);
		$new->bindParam(':password', password_hash($_POST['password'], PASSWORD_BCRYPT));
		
		if($new->execute()){
			$message2 = 'Your credential successfully';
		}else{
			$message = 'Error';
		}
	}
}

session_start();
if(isset($_SESSION['user_id'])){
	header("Location: dashboard.php");
}


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Registration</title>
        <link rel="stylesheet" href="css/robot-font.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
        
        
        
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <style>
        body{
            font-family: 'roboto';
            font-weight: 300;
        }
        label{
            font-family: 'roboto';
            font-weight: 300;
        }
    </style>
    </head>
    <body>
        <div class="navbar navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand">Login & Registration</a>
            </div>
            
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="login.php">Login</a></li>
                    <li><a href="registration.php">Registration</a></li>
                </ul>
            </div>  
        </div>
        
        
            <div class="container_fluid text-center">
                <div class="row">
                    <div col-sm-8 col-sm-offset-2>
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Registration</h3></div>
                             <div class="panel-body">
                                
									<?php if(!empty($message)):?>
								<div class="alert-danger">
										<p><?php echo $message;?></p>
								</div>
									<?php endif;?>
								
								<?php if(!empty($message2)) :?>
								<div class="alert-success">
									<p><?php echo $message2; ?></p>
								</div>
								<?php endif;?>
								
								<form action="" method="POST" class="form-horizontal">    
                                    
                                    <div class="form-group">
                                        <label for="username" class="col-sm-4 control-label">Username</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="username" id="username" placeholder="Enter your user name"/>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="email" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="email" id="email" placeholder="Enter your user email"/>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="password" class="col-sm-4 control-label">password</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="password" id="password" placeholder="Enter your user password"/>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="confirm_password" class="col-sm-4 control-label">confirm password</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="confirm_password" id="confirm_password" placeholder="Enter your confirn password"/>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                    
                                        <div class="col-sm-6 col-sm-offset-2">
                                            <input class="btn btn-primary" type="submit" name="submit" id="submit" value="Save"/>
                                        </div>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    
    </body>
</html>
<?php
require 'db.php';
@session_start();

if(isset($_SESSION['user_id'])){
	header('Location: dashboard.php');
}

$error = array();
$message = '';

if(isset($_POST['submit'])){
	if(empty($_POST['email'])){
		$error[] = "You must enter your email !!";
	}
	if(empty($_POST['password'])){
		$error[] = "You must enter your password !! ";
	}
	if(!empty($error)){
		foreach($error as $single_error){
			$message .= $single_error."<br>";
		}
	}else{
		//user can login
		$new = $connection->prepare('SELECT * FROM users WHERE email = :email');
		$new->bindParam(':email', $_POST['email']);
		$new->execute();
		$resource = $new->fetch(PDO::FETCH_ASSOC);
		
		if(count($resource) > 0 && password_verify($_POST['password'], $resource['password'])){
			//die ('u are logged in');
			$_SESSION['user_id'] = $resource['id'];
			header('Location: dashboard.php');
			
		}else{
			die("wrong credintial");
		}
		
	}
	
}



?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link rel="stylesheet" href="css/robot-font.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <style>
        body{
            font-family: 'roboto';
            font-weight: 300;
        }
        label{
            font-family: 'roboto';
            font-weight: 300;
        }
    </style>
    </head>
    <body>
        <div class="navbar navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand">Login & Registration</a>
            </div>
            
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="login.php">Login</a></li>
                    <li><a href="registration.php">Registration</a></li>
                </ul>
            </div>  
        </div>
        
        
            <div class="container_fluid text-center">
                <div class="row">
                    <div col-sm-8 col-sm-offset-2>
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Login</h3></div>
                            <div class="panel-body">
                                <?php if(!empty($message)) :?>
								<div class="alert-danger">
									<p><?php echo $message; ?></p>
								</div>
								<?php endif ;?>
                                
                                
                                <form action="" method="POST" enctype="multipart/form-data" class="form-horizontal">    
                                    
                                    <div class="form-group">
                                        <label for="email" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="email" id="username" placeholder="Enter your user email"/>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="password" class="col-sm-4 control-label">password</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="password" id="password" placeholder="Enter your user password"/>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-2">
                                            <input  type="checkbox" name="remember_me" id="remember_me"/> <label for="remember">Remember Me</label>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-2">
                                            <input class="btn btn-primary" type="submit" name="submit" id="submit" value="Log In"/>
                                        </div>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    
    </body>
</html>
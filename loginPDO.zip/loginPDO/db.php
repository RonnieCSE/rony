<?php
$host = 'localhost';
$dbname = 'logreg';
$username = 'root';
$password = '';

try{
	$connection = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
}catch(PDOException $e){
	die('Database Connection Failed!!!' .$e->getMessage());
}
?>
	
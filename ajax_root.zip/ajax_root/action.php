<?php
//print_r($_GET);

$name = $_GET['name'];
$pass = $_GET['pass'];

echo "my Name is $name . password is $pass.";

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

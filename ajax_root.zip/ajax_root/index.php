<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script type="text/javascript">
        function submit_form(){
            
            var name = $('.name').val();
            var pass = $('.password').val();
            
            var dataString = 'name='+name+'&pass='+pass;
            
            $.ajax({
                            type: "GET",
                            url: "action.php",
                            data: dataString,
                            cache: false,
                            success: function (result) {
//                                                 alert(result);
                                $('.output').html(result);
                            }
                        });
        }
    </script>
    </head>
    <body>
        
            <input type="text" class="name"  placeholder="name">
            <input type="password" class="password" placeholder="password">
            <input type="button" value="submit" onclick="submit_form()">
            <p class="output">  </p>
        
    </body>
</html>

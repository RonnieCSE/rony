<?php
require_once 'classes/blog.php';
$std_obj = new Blog();

$id = $_GET['id'];
$std_obj->delete($id);
echo $id;

?>

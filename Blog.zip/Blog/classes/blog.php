<?php

require_once 'db_connection.php';

class Blog {
    public function __construct(){
        $db = new Db_connection();
    }
    
    public function savePost($data){
        $title = mysql_escape_string($_POST['title']);
        $author = mysql_escape_string($_POST['author']);
        $post = mysql_escape_string($_POST['post']);
        
        $sql = "INSERT INTO post(title, author, post) VALUES('$title', '$author', '$post')";
        if (!mysql_query($sql)){
            return 'Sql query failed!!';
        }  else {
            return 'Post saves successfully';
        }
    }
    
    public function read(){
        $sql = "SELECT * FROM post ORDER BY id DESC";
        return mysql_query($sql);
    }
    
    public function delete($id){
        $sql = "DELETE FROM post WHERE id = $id";
        if (mysql_query($sql)){
            header("Location: index.php");
        }
    }
    public function edit($id){
        $sql = "SELECT * FROM post WHERE id = $id";
        return mysql_query($sql);
    }
    public function update($data){
        
        $title = mysql_escape_string($_POST['title']);
        $author = mysql_escape_string($_POST['author']);
        $post = mysql_escape_string($_POST['post']);
        $id = mysql_escape_string($_POST['id']);
        
        $sql = "UPDATE post SET title = '{$title}', author= '{$author}', post='{$post}' WHERE id= $id ";
        if (!mysql_query($sql)){
            die('query failed');
        }  else {
            header("Location: index.php");
        }
    }
}

?>





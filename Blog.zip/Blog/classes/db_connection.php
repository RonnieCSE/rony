<?php

class Db_connection {
    public function __construct()
        {
            $host = 'localhost';
            $username = 'root';
            $password = '';
            $dbname = 'blog';

            $con = mysql_connect($host, $username, $password);
            if (!$con){
                die('mysql connection failed');
            }else {
                mysql_select_db($dbname);
            }
        }
}

?> 

<?php
$search_text = $_GET['text'];
echo $search_text;

$data = array('php','css','html','js','ajax','linux');
if(in_array($search_text, $data))
{
    echo " Found";
} else {
    echo " Not Found";
}


?>
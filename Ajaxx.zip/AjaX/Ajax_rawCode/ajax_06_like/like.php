<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'db_ajax';

$conn = mysqli_connect($host, $user, $pass, $dbname);
if (!$conn) {
    die('Server not connected');
}

if(isset($_GET['id']))
{
    $id = $_GET['id'];
    $rslt = mysqli_query($conn, "SELECT * FROM tbl_like_count WHERE like_id='$id' ");
    $likeInfo = mysqli_fetch_assoc($rslt);
    
    $likeCount = $likeInfo['like_count']+1;
    
    $update = "UPDATE tbl_like_count SET like_count='$likeCount' WHERE like_id='$id' ";
    mysqli_query($conn, $update);
}


$sql = "SELECT * FROM tbl_like_count";
$result = mysqli_query($conn, $sql);
?>
<table border="1" align="center">
    <tr>
        <td>Company Name</td>
        <td>Action</td>
    </tr>
    <?php 
    while ($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo $row['company_name'];?></td>
        <td>(<?php echo $row['like_count'];?>)<a href="" onclick="update_like(<?php echo $row['like_id'];?>)"> Like</a></td>
    </tr>
    
        <?php  } ?>
</table>
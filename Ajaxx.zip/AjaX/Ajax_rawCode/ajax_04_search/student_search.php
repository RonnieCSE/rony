<?php
$search_text = $_GET['text'];

//echo $search_text;
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'db_ajax';

$conn = mysqli_connect($host, $user, $pass, $dbname);
if (!$conn) {
    die('Server not connected');
}

if (isset($search_text)) {
    $sql = "SELECT * FROM tbl_student WHERE name LIKE '%$search_text%' OR mobile LIKE '%$search_text%' ";
} else {
    $sql = "SELECT * FROM tbl_student";
}
$result = mysqli_query($conn, $sql);
?>
<table border="1" align="center" width="800px">
    <thead>
        <tr>
            <th>Student Id</th>
            <th>Student Name</th>
            <th>Student Email</th>
            <th>Student Mobile No.</th>
        </tr>
    </thead>
    <tbody>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['std_id'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['mobile'] ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>




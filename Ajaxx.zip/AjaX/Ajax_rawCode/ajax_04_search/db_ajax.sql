-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2016 at 02:25 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ajax`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `std_id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`std_id`, `name`, `email`, `mobile`) VALUES
(1, 'Ronnie', 'ronnie@gmail.com', '05698'),
(2, 'kamal', 'kamal@gmail.com', '6541968498'),
(3, 'hasan', 'hasan@gmail.com', '641611'),
(4, 'kasem', 'kasem@gmail.com', '6518548'),
(5, 'abul', 'abul@gmail.com', '0651956'),
(6, 'alim', 'alim@gmail.com', '5961986'),
(7, 'babu', 'babu@gmail.com', '8787'),
(8, 'bablu', 'bablu@gmail.com', '6498689'),
(9, 'delower', 'delower@gmail.com', '9488587'),
(10, 'anower', 'anower@gmail.com', '84941'),
(11, 'elias', 'elias@gmail.com', '8498465'),
(12, 'emon', 'emon@gmail.com', '984965'),
(13, 'faruk', 'faruk@gmail.com', '3561968'),
(14, 'foysal', 'foysal@gmail.com', '784815'),
(15, 'gazi', 'gazi@gmail.com', '285486'),
(16, 'hasan', 'hasan@gmail.com', '89498567'),
(17, 'hemel', 'hemel@gmail.com', '45671365'),
(18, 'ismail', 'ismail@gmail.com', '659852'),
(19, 'japor', 'japor@gmail.com', '6598545'),
(20, 'javed', 'javed@gmail.com', '2587655'),
(21, 'limon', 'limon@gmail.com', '124568'),
(22, 'liza', 'liza@gmail.com', '958855'),
(23, 'moyna', 'moyna@gmail.com', '824845'),
(24, 'nisan', 'nisan@gmail.com', '968755'),
(25, 'nowrin', 'nowrin@gmail.com', '897665');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`std_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `std_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta charset="UTF-8">
            <title></title>
            <script type="text/javascript">
                // code for modern browsers
                var xmlhttp = false;
                try {
                    // code for old IE browsers
                    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
                    //alert(xmlhttp);
                    //alert("You are using Microsoft Internet Explorer");
                } catch (e) {
                    //alert(e);
                    //If not, then use the older active x object

                    try {
                        //if we are using internet Explorer
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                        //alert("You are using Microsoft Internet Explorer");
                    } catch (E) {
                        xmlhttp = false;
                    }
                }

                //alert(typeof XMLHttpRequest);
                //if we are using a non-IE browser, create a javascript instance of the object
                if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
                    xmlhttp = new XMLHttpRequest();
                    //alert("You are not using Microsoft Internet Explorer");
                }


                function makerequest(given_text, objID)
                {
                    //alert(given_text);
                    //var obj = document.getElementById(objID);
                    //serverPage = 'search.php?text=' + given_text+'&abc='+d23;
                    serverPage = 'student_search.php?text=' + given_text;
                    xmlhttp.open("GET", serverPage);
                    xmlhttp.onreadystatechange = function ()
                    {
                        //alert(xmlhttp.readyState);
                        //alert(xmlhttp.status);
                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            // alert(xmlhttp.responseText);
                            document.getElementById(objID).innerHTML = xmlhttp.responseText;
                        }
                    }
                    xmlhttp.send(null);
                }

            </script>

    </head>
    <body onload="makerequest('', 'res')">
        <span>Search Student</span>
        <input type="text" id="given_text" onkeyup="makerequest(this.value, 'res');"/>
        <br /><br /><hr />
        <span id="res"></span>
    </body>
</html>


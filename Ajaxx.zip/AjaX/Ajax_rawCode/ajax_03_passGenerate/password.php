<?php

$length = $_GET['length'];

$alpha = array('a','V','@','&','I','K','S','T','m','n','1');
$password = '';

for($i=0; $i<=$length-1; $i++)
{
    $r= rand(0,9);
    $password .= $alpha[$r];
}
echo $password;
-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2016 at 02:26 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajax_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `search_data`
--

CREATE TABLE `search_data` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `search_data`
--

INSERT INTO `search_data` (`id`, `name`, `email`) VALUES
(1, 'kamal', 'kamal@gmail.com'),
(2, 'kasem', 'kasem@gmail.com'),
(3, 'abul', 'abul@gmail.com'),
(4, 'alim', 'alim@gmail.com'),
(5, 'babu', 'babu@gmail.com'),
(6, 'bablu', 'bablu@gmail.com'),
(7, 'delower', 'delower@gmail.com'),
(8, 'Anower', 'anower@gmail.com'),
(9, 'elias', 'elias@gmail.com'),
(10, 'emon', 'emon@gmail.com'),
(11, 'faruk', 'faruk@gmail.com'),
(12, 'foysal', 'foysal@gmail.com'),
(13, 'gazi', 'gazi@gmail.com'),
(14, 'hasan', 'hasan@gmail.com'),
(15, 'hemel', 'hemel@gmail.com'),
(16, 'Ismail', 'ismail@gmail.com'),
(17, 'japor', 'japor@gmail.com'),
(18, 'javed', 'javed@gmail.com'),
(19, 'limon', 'limon@gmail.com'),
(20, 'liza', 'liza@gmail.com'),
(21, 'moyna', 'moyna@gmail.com'),
(22, 'mafuz', 'mafuz@gmail.com'),
(23, 'Nisan', 'nisan@gmail.com'),
(24, 'Nowrin', 'nowrin@gmail.com'),
(25, 'Omi', 'omi@gmail.com'),
(26, 'piyash', 'piash@gmail.com'),
(27, 'ontor', 'ontor@gmail.com'),
(28, 'ontor', 'ontor@gmail.com'),
(29, 'ontor', 'ontor@gmail.com'),
(30, 'ontor', 'ontor@gmail.com'),
(31, 'ontor', 'ontor@gmail.com'),
(32, 'ontor', 'ontor@gmail.com'),
(33, 'ontor', 'ontor@gmail.com'),
(34, 'ontor', 'ontor@gmail.com'),
(35, 'payel', 'payel@gmail.com'),
(36, 'payel', 'payel@gmail.com'),
(37, 'payel', 'payel@gmail.com'),
(38, 'Qader', 'qader@gmail.com'),
(39, 'Ronnie', 'ronnie@gmail.com'),
(40, 'Ratul', 'ratul@gmail.com'),
(41, 'Rayhan', 'rayhan@gmail.com'),
(42, 'Santo', 'santo@gmail.com'),
(43, 'sakib', 'sakib@gmail.com'),
(44, 'sagor', 'sagor@gmail.com'),
(45, 'tumpa', 'tumpa@gmail.com'),
(46, 'talha', 'talha@gmail.com'),
(47, 'tutul', 'tutul@gmail.com'),
(48, 'urmi', 'urmi@gmail.com'),
(49, 'Oyshi', 'oyshi@gmail.com'),
(50, 'yasmin', 'yasmin@gmail.com'),
(51, 'yasin', 'yasin@gmail.com'),
(52, 'Zia', 'zia@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `search_data`
--
ALTER TABLE `search_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `search_data`
--
ALTER TABLE `search_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

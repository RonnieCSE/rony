<?php
$con = new mysqli('localhost','root','', 'ajax_data');
if (!$con){
    echo "Failed!";
}

?>
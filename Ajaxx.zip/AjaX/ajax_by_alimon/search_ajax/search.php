<?php
require_once './connecion/connection.php';
$search = $_POST['search'];
$sql = "SELECT * FROM search_data WHERE name LIKE '%$search%' ";

$result = $con->query($sql);
$count = $result->num_rows;
?>
<table class="table table-striped">
    <tr>
        <th>Name</th>
        <th>Email</th>
    </tr>
    <?php
//echo $count;
    if ($count > 0) {
        while ($data = $result->fetch_assoc()){
            
        //print_r($data);
        echo "<tr>";
            echo "<td>" . $data['name'] . "</td>";
            echo "<td>" . $data['email'] . "</td>";
        echo "</tr>";
        }
    } else {
        echo "<p style='color: red;'>Data not Found!!</p>";
    }
//var_dump($result);
    ?>
</table>

<?php
mysql_connect('localhost','root') or die('Server not Found!!');
mysql_select_db('log_reg') or die('database not found!!');
?>

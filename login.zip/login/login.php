<?php
session_start();
if (isset($_SESSION['user_id'])){
    header("Location: dashboard.php");
}

require './db.php';

$error = array();
$message=  '';

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (empty($_POST['email'])){
        $error[] = 'You must enter your email address';
    }
    if (empty($_POST['password'])){
        $error[] = 'You must enter your password';
    }
    
    if (!empty($error)){
        foreach ($error as $single_error){
            $message .= $single_error .'<br>';
        }
    }  else {
        //user can login
        $email = $_POST['email'];
        $password = md5($_POST['password']);
       //$password = $_POST['password'];
        
        
        $select = mysql_query("SELECT * FROM users WHERE email = '$email' && password= '$password' ");
        $num_row = mysql_num_rows($select);
        $fetch = mysql_fetch_array($select);
        
        if ($num_row == 1){
            //for session start 1 no. line
            $_SESSION['user_id'] = $fetch['id'];
            header("Location:dashboard.php");
        }  else {
            header("Location:login.php");    
        }
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link rel="stylesheet" href="css/robot-font.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <style>
        body{
            font-family: 'roboto';
            font-weight: 300;
        }
        label{
            font-family: 'roboto';
            font-weight: 300;
        }
    </style>
    </head>
    <body>
        <div class="navbar navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand">Login & Registration</a>
            </div>
            
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="login.php">Login</a></li>
                    <li><a href="registration.php">Registration</a></li>
                </ul>
            </div>  
        </div>
        
        
            <div class="container_fluid text-center">
                <div class="row">
                    <div col-sm-8 col-sm-offset-2>
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Login</h3></div>
                            <div class="panel-body">
                                
                                <?php if (!empty($message)):?>
                                    <div class="alert-danger">
                                        <p><?php echo $message;?></p>
                                    </div>
                                <?php endif;?>
                                
                                
                                
                                <form action="" method="POST" enctype="multipart/form-data" class="form-horizontal">    
                                    
                                    <div class="form-group">
                                        <label for="email" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="email" id="username" placeholder="Enter your user email"/>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="password" class="col-sm-4 control-label">password</label>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="password" id="password" placeholder="Enter your user password"/>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-2">
                                            <input  type="checkbox" name="remember_me" id="remember_me"/> <label for="remember">Remember Me</label>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-2">
                                            <input class="btn btn-primary" type="submit" name="submit" id="submit" value="Log In"/>
                                        </div>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    
    </body>
</html>
<?php
require './db.php';
//dashboard secure
session_start();
if (isset($_SESSION['user_id'])){
//    he can stay this page
}  else {
    header("Location: login.php");
}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Dashboard</title>
        <link rel="stylesheet" href="css/robot-font.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css"/>
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
        
        
        
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <style>
        body{
            font-family: 'roboto';
            font-weight: 300;
        }
        label{
            font-family: 'roboto';
            font-weight: 300;
        }
    </style>
    </head>
    <body>
        <div class="navbar navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand">Login & Registration</a>
            </div>
            
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown"><a href="" class="dropdown-toggole" data-toggle="dropdown">
        <?php
        $session_id = $_SESSION['user_id'];
                $select = mysql_query("SELECT * FROM users WHERE id = $session_id  ");
                $fetch = mysql_fetch_array($select);?>
        
                            <?php echo $fetch['username'];?> <strong class="caret"></strong></a>
                        <ul class="dropdown-menu">
                            <li><a href="logout.php">Logout</a></li>
                            <li><a href="#">Setting</a></li>
                        </ul>
                    </li>
                </ul>
            </div>  
        </div>
        
        
            <div class="container_fluid text-center">
                <div class="row">
                    <div col-sm-8 col-sm-offset-2>
                        <div class="panel panel-default">
                            <div class="panel-heading"><h3>Dashboard</h3></div>
                            <div class="panel-body">
                                <p>You are logged in!!!</p>
                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    
    </body>
</html>